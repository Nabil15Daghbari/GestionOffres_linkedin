package tn.cpg.internservice.dto;

import lombok.Data;

@Data
public class StatusDTO {
	String status ;
}
