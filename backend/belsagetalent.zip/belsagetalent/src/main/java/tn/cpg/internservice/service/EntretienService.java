package tn.cpg.internservice.service;


import tn.cpg.internservice.dto.EntretienDto;

public interface EntretienService extends BaseService<EntretienDto, Integer> {
}
