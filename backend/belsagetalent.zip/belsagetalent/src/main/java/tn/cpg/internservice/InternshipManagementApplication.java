package tn.cpg.internservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternshipManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternshipManagementApplication.class, args);
	}

}
