package tn.cpg.internservice.exception;

public class EmptyFileException extends Exception{
	   public EmptyFileException() {}
	    public EmptyFileException(String message) {
	        super(message);
	    }
}
