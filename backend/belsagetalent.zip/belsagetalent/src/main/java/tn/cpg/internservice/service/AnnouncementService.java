package tn.cpg.internservice.service;

import tn.cpg.internservice.dto.AnnouncementDto;

public interface AnnouncementService extends BaseService<AnnouncementDto, Integer> {

}
