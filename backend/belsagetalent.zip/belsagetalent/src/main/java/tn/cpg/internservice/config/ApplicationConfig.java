package tn.cpg.internservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import lombok.RequiredArgsConstructor;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import java.util.Arrays;
import java.util.Collections;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpHeaders.ORIGIN;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;
import static org.springframework.web.bind.annotation.RequestMethod.PATCH;
@Configuration
@RequiredArgsConstructor
public class ApplicationConfig {

	  @Bean
	  public CorsFilter corsFilter() {
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    final CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true);
	    config.setAllowedOrigins(Collections.singletonList("http://localhost:4850"));
	    config.setAllowedHeaders(Arrays.asList(
	            ORIGIN,
	            CONTENT_TYPE,
	            ACCEPT,
	            AUTHORIZATION
	    ));
	    config.setAllowedMethods(Arrays.asList(
	            GET.name(),
	            POST.name(),
	            DELETE.name(),
	            PUT.name(),
	            PATCH.name()
	    ));
	    source.registerCorsConfiguration("/**", config);
	    return new CorsFilter(source);

	  }

}
