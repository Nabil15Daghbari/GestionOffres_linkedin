package tn.cpg.internservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
